import { Data, Override } from "framer"

const connectorState = Data({ open: false })

export const cogitoConnector: Override = () => {
  console.log('hello')
  return {
    onTrigger: () => {
      console.log('onTrigger')
      connectorState.open = true
    },
    onClosed() {
      connectorState.open = false
    },
    open: connectorState.open
  }
}
