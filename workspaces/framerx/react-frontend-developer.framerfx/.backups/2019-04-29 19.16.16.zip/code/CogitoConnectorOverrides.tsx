import { Data, Override } from "framer"

const connectorState = Data({ open: false })

export const cogitoConnector: Override = () => {
  console.log('hello')
  return {
    onOpen: () => {
      console.log('onTrigger')
      connectorState.open = true
    },
    onDone: () => {
      connectorState.open = false
    },
    open: connectorState.open
  }
}
