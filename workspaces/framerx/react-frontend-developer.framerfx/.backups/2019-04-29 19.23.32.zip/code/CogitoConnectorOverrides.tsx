import { Data, Override } from "framer"

const connectorState = Data({ open: false })

export const cogitoConnector: Override = () => {
  return {
    onOpen: () => {
      console.log('onTrigger')
      connectorState.open = true
    },
    onDone: () => {
      connectorState.open = false
    },
    open: connectorState.open
  }
}
